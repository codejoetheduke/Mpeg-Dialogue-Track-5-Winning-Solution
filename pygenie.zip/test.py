from pygenie import genie_help

stdout, stderr, code = genie_help()
print(stdout)