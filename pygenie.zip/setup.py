from setuptools import setup, find_packages

setup(
    name="pygenie",
    version="0.1.0",
    description="Python wrapper for the MPEG-G Genie binary",
    packages=find_packages(),
    include_package_data=True,
    package_data={"pygenie": ["genie"]},
    install_requires=[],
    python_requires=">=3.6",
)
