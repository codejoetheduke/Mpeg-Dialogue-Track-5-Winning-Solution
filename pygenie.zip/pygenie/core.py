import os
import subprocess
import stat

# Locate the binary inside the package
GENIE_BIN = os.path.join(os.path.dirname(__file__), "genie")

# Ensure the binary is executable
st = os.stat(GENIE_BIN)
os.chmod(GENIE_BIN, st.st_mode | stat.S_IEXEC)
cpus = os.cpu_count()

def run_command(args):
    """Run genie with a list of arguments and return stdout/stderr/returncode."""
    cmd = [GENIE_BIN] + args
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.stdout, result.stderr, result.returncode

# ---------------- Fastq ----------------
def transcode_fastq(input_file, output_file, input_supp=None, output_supp=None,
                    threads=None, force=False):
    """Convert between fastq and mgrec files."""
    args = ["transcode-fastq"]
    if force:
        args.append("-f")  # <-- add early
    args += ["-i", input_file, "-o", output_file]
    if input_supp:
        args += ["--input-suppl-file", input_supp]
    if output_supp:
        args += ["--output-suppl-file", output_supp]
    if threads:
        args += ["-t", str(threads)]
    return run_command(args)

# ---------------- Sam ----------------
def transcode_sam(input_file, output_file, ref=None, threads=None, force=False, working_dir=None):
    """Convert between sam and mgrec files."""
    args = ["transcode-sam", "-i", input_file, "-o", output_file]
    if ref:
        args += ["--ref", ref]
    if threads:
        args += ["-t", str(threads)]
    if force:
        args += ["-f"]
    if working_dir:
        args += ["--working-dir", working_dir]
    return run_command(args)

# ---------------- Run (Compress/Decompress) ----------------
def run(input_file, output_file, threads=cpus, force=True):
    """
    Wrapper for `genie run` command.
    
    Args:
        input_file (str): Path to input file (.mgb, .fastq, etc.)
        output_file (str): Path to output file (.fastq, .mgb, etc.)
        threads (int): Number of threads to use
        force (bool): Overwrite existing outputs if True
    """
    cmd = [
        GENIE_BIN,
        "run",
        "-i", input_file,
        "-o", output_file,
        "-t", str(threads)
    ]
    if force:
        cmd.insert(2, "-f")  # after "run"

    # Run genie silently (no stdout/stderr, only tqdm remains)
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

# ---------------- Help ----------------
def genie_help():
    """Show help information for Genie."""
    return run_command(["help"])
